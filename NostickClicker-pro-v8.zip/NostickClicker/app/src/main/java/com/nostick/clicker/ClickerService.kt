/*
 * NostickClicker — Auto Clicker
 * Copyright (c) 2024 NostickClicker. All rights reserved.
 *
 * ClickerService.kt
 * ─────────────────
 * This is the heart of NostickClicker. It is an AccessibilityService that:
 *
 *  1. Draws a translucent, draggable floating control bar over any app using
 *     WindowManager with FLAG_NOT_FOCUSABLE so ALL touch events pass through
 *     to the underlying app (game, browser, etc.). No freezing, ever.
 *
 *  2. Manages a dynamic list of draggable "click point" overlays. Each point
 *     can be dragged to any screen position independently.
 *
 *  3. Injects gestures via dispatchGesture() on a tight Handler/Runnable loop.
 *     Minimum interval: 40 ms. The loop fires at each click point in sequence.
 *
 *  4. Exposes a live singleton reference (instance) so MainActivity can check
 *     whether the service is connected.
 *
 * Privacy guarantee: this service never reads screen content, never accesses
 * network, and never stores any information beyond the user's chosen interval
 * (saved in SharedPreferences via Prefs).
 */

package com.nostick.clicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import android.widget.SeekBar
import com.nostick.clicker.databinding.DialogSettingsBinding
import kotlin.math.roundToInt

class ClickerService : AccessibilityService() {

    // ── Singleton reference ──────────────────────────────────────────────────
    companion object {
        /** Non-null while the service is connected and running. */
        @Volatile var instance: ClickerService? = null
            private set

        private const val FOREGROUND_ID = 1001
        private const val GESTURE_DURATION_MS = 1L   // tap duration (synthetic)
    }

    // ── Window manager ───────────────────────────────────────────────────────
    private lateinit var windowManager: WindowManager

    // ── Floating control bar ─────────────────────────────────────────────────
    private var menuView: View? = null
    private lateinit var menuParams: WindowManager.LayoutParams

    // ── Click point overlays ─────────────────────────────────────────────────
    /** Each entry: Pair(view, WindowManager.LayoutParams) */
    private val clickPoints = mutableListOf<Pair<View, WindowManager.LayoutParams>>()
    private val profileControls = mutableListOf<Pair<View, WindowManager.LayoutParams>>()
    private val profileViewEvents = mutableMapOf<View, ControlEvent>()
    private var activeProfile: ControlProfile? = null
    private var editorOverlay: View? = null
    private var editorMode = false

    // ── Clicker loop ─────────────────────────────────────────────────────────
    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var clickIntervalMs = Prefs.DEFAULT_INTERVAL_MS
    private var loopIndex = 0   // cycles through click points in sequence

    private val clickRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            if (clickPoints.isNotEmpty()) {
                dispatchNextClick()
            }
            handler.postDelayed(this, clickIntervalMs)
        }
    }

    // ── Vibrator ─────────────────────────────────────────────────────────────
    private var vibrator: Vibrator? = null

    // ════════════════════════════════════════════════════════════════════════
    // Lifecycle
    // ════════════════════════════════════════════════════════════════════════

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        vibrator = getVibrator()
        clickIntervalMs = Prefs.getClickIntervalMs(this)
        activeProfile = ProfileStore.load(this).firstOrNull()
        startForegroundNotification()
        showFloatingMenu()
        showProfileControls()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    /** Required by AccessibilityService; NostickClicker does not process events. */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    /** Required by AccessibilityService. */
    override fun onInterrupt() {
        stopClickLoop()
    }

    // ════════════════════════════════════════════════════════════════════════
    // Foreground Notification
    // ════════════════════════════════════════════════════════════════════════

    private fun startForegroundNotification() {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(
            this,
            getString(R.string.notif_channel_id)
        )
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(R.drawable.ic_play)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()

        startForeground(FOREGROUND_ID, notification)
    }

    // ════════════════════════════════════════════════════════════════════════
    // Floating Menu
    // ════════════════════════════════════════════════════════════════════════

    private fun showFloatingMenu() {
        if (menuView != null) return

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.layout_floating_menu, null)

        menuParams = buildOverlayParams(
            width  = dpToPx(56),
            height = WindowManager.LayoutParams.WRAP_CONTENT,
            x      = 16,
            y      = 200
        )

        // Drag
        setupMenuDrag(view, menuParams)

        // Buttons
        view.findViewById<ImageButton>(R.id.btnPlayPause).setOnClickListener {
            vibrate()
            toggleClickLoop(it as ImageButton)
        }
        view.findViewById<ImageButton>(R.id.btnAdd).setOnClickListener {
            vibrate()
            addClickPoint()
        }
        view.findViewById<ImageButton>(R.id.btnRemove).setOnClickListener {
            vibrate()
            removeLastClickPoint()
        }
        view.findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            vibrate()
            showEditorOverlay()
        }
        view.findViewById<ImageButton>(R.id.btnClose).setOnClickListener {
            vibrate()
            menuView?.visibility = View.GONE
        }
        view.findViewById<ImageButton>(R.id.btnClose).setOnLongClickListener {
            stopClickLoop()
            menuView?.visibility = View.GONE
            Toast.makeText(this, R.string.toast_emergency_stop, Toast.LENGTH_SHORT).show()
            true
        }
        view.findViewById<ImageButton>(R.id.btnMinimize).setOnClickListener {
            menuView?.visibility = View.GONE
        }

        windowManager.addView(view, menuParams)
        menuView = view
    }

    fun revealControls() {
        menuView?.visibility = View.VISIBLE
        profileControls.forEach { it.first.visibility = View.VISIBLE }
    }

    fun stopAllControls() {
        stopClickLoop()
        editorMode = false
        menuView?.visibility = View.GONE
        profileControls.forEach { it.first.visibility = View.GONE }
    }

    fun activateProfile(profile: ControlProfile) {
        activeProfile = profile
        clearProfileControls()
        showProfileControls()
    }

    fun openEditorFromDashboard() {
        showEditorOverlay()
    }

    private fun showEditorOverlay() {
        if (editorOverlay != null) return
        editorMode = true
        menuView?.visibility = View.GONE
        val root = FrameLayout(this).apply { setBackgroundColor(0x11000000) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dpToPx(4), dpToPx(3), dpToPx(4), dpToPx(3))
            background = GradientDrawable().apply { setColor(0xDD311B45.toInt()); cornerRadius = dpToPx(12).toFloat() }
        }
        fun tool(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text; textSize = 11f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xCC6A1B9A.toInt()); setOnClickListener { action() }
        }
        bar.addView(tool("＋", { addEditorControl(ControlWidget.BUTTON) }))
        bar.addView(tool("◉", { addEditorControl(ControlWidget.MOVE_JOYSTICK) }))
        bar.addView(tool("◎", { addEditorControl(ControlWidget.CAMERA_JOYSTICK) }))
        bar.addView(tool(getString(R.string.save_profile), { saveActiveProfile() }))
        bar.addView(tool(getString(R.string.choose_profile), { cycleProfile() }))
        bar.addView(tool("×", { closeEditorOverlay() }))
        val barParams = FrameLayout.LayoutParams(dpToPx(330), dpToPx(52), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        barParams.topMargin = dpToPx(12); root.addView(bar, barParams)
        // Only the compact toolbar is touchable; the game and editable controls
        // remain visible beneath it instead of being covered by a full-screen view.
        val params = buildOverlayParams(WindowManager.LayoutParams.MATCH_PARENT, dpToPx(72), y = 0)
        windowManager.addView(root, params); editorOverlay = root
        profileControls.forEach { it.first.visibility = View.VISIBLE }
    }

    private fun closeEditorOverlay() {
        editorMode = false
        editorOverlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        editorOverlay = null; menuView?.visibility = View.VISIBLE
    }

    private fun saveActiveProfile() {
        activeProfile?.let { ProfileStore.upsert(this, it) }
        Toast.makeText(this, R.string.profile_saved, Toast.LENGTH_SHORT).show()
    }

    private fun cycleProfile() {
        val profiles = ProfileStore.load(this)
        if (profiles.isEmpty()) { Toast.makeText(this, R.string.no_profiles, Toast.LENGTH_SHORT).show(); return }
        val index = profiles.indexOfFirst { it.id == activeProfile?.id }
        activeProfile = profiles[(index + 1).mod(profiles.size)]
        clearProfileControls(); showProfileControls()
        Toast.makeText(this, getString(R.string.profile_selected, activeProfile?.name ?: ""), Toast.LENGTH_SHORT).show()
    }

    private fun addEditorControl(widget: ControlWidget) {
        val profile = activeProfile ?: ControlProfile("default", "Default", "").also { activeProfile = it }
        val label = when (widget) { ControlWidget.BUTTON -> "Button"; ControlWidget.MOVE_JOYSTICK -> "MOVE"; ControlWidget.CAMERA_JOYSTICK -> "CAM" }
        profile.controls.add(ControlEvent(System.nanoTime(), label, ControlEventType.SCREEN, ControlAction.CLICK, widget))
        clearProfileControls(); showProfileControls()
    }

    private fun clearProfileControls() {
        profileControls.forEach { try { windowManager.removeView(it.first) } catch (_: Exception) {} }
        profileControls.clear(); profileViewEvents.clear()
    }

    private fun showProfileControls() {
        val profile = activeProfile ?: return
        if (!profile.screenEventsEnabled) return
        profile.controls.filter { it.enabled && it.type == ControlEventType.SCREEN }.forEach { event ->
            val controlView: View = if (event.widget == ControlWidget.BUTTON) {
                Button(this).apply {
                    text = event.label.ifBlank { event.action.name }
                    textSize = 11f; setTextColor(0xFFFFFFFF.toInt())
                    setBackgroundColor(0xAA6A1B9A.toInt()); setPadding(2, 2, 2, 2)
                }
            } else {
                FrameLayout(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL; setColor(0x66311B45)
                        setStroke(dpToPx(2), 0xCCBB86FC.toInt())
                    }
                    val knob = View(this@ClickerService).apply {
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xDDFFFFFF.toInt()) }
                    }
                    addView(knob, FrameLayout.LayoutParams(dpToPx(34), dpToPx(34), Gravity.CENTER))
                }
            }
            val width = dpToPx((event.width * 360f).coerceIn(52f, 180f).roundToInt())
            val height = dpToPx((event.height * 720f).coerceIn(48f, 140f).roundToInt())
            val params = buildOverlayParams(width, height,
                (resources.displayMetrics.widthPixels * event.x).roundToInt(),
                (resources.displayMetrics.heightPixels * event.y).roundToInt())
            var toggled = false
            var spam = false
            var editorDownX = 0f; var editorDownY = 0f; var editorStartX = 0; var editorStartY = 0
            val spamRunnable = object : Runnable {
                override fun run() {
                    if (!spam) return
                    dispatchTapAt(params.x + width / 2f, params.y + height / 2f)
                    handler.postDelayed(this, event.intervalMs.coerceIn(10L, 10000L))
                }
            }
            controlView.setOnTouchListener { _, motion ->
                if (editorMode) {
                    when (motion.action) {
                        MotionEvent.ACTION_DOWN -> { editorDownX = motion.rawX; editorDownY = motion.rawY; editorStartX = params.x; editorStartY = params.y }
                        MotionEvent.ACTION_MOVE -> {
                            params.x = (editorStartX + motion.rawX - editorDownX).roundToInt()
                            params.y = (editorStartY + motion.rawY - editorDownY).roundToInt()
                            windowManager.updateViewLayout(controlView, params)
                        }
                        MotionEvent.ACTION_UP -> {
                            profileViewEvents[controlView]?.let {
                                it.x = params.x.toFloat() / resources.displayMetrics.widthPixels
                                it.y = params.y.toFloat() / resources.displayMetrics.heightPixels
                            }
                        }
                    }
                    true
                } else if (motion.action == MotionEvent.ACTION_DOWN) {
                    when {
                        event.widget != ControlWidget.BUTTON -> Unit
                        else -> when (event.action) {
                        ControlAction.CLICK -> dispatchTapAt(params.x + width / 2f, params.y + height / 2f)
                        ControlAction.TOGGLE -> {
                            toggled = !toggled; spam = toggled
                            if (spam) handler.post(spamRunnable) else handler.removeCallbacks(spamRunnable)
                        }
                        ControlAction.SPAM -> { spam = true; handler.post(spamRunnable) }
                        ControlAction.HOLD -> dispatchHoldAt(params.x + width / 2f, params.y + height / 2f)
                        }
                    }
                    true
                } else if (event.widget != ControlWidget.BUTTON && motion.action == MotionEvent.ACTION_MOVE) {
                    val cx = params.x + width / 2f; val cy = params.y + height / 2f
                    val dx = (motion.rawX - cx).coerceIn(-width / 2f, width / 2f)
                    val dy = (motion.rawY - cy).coerceIn(-height / 2f, height / 2f)
                    dispatchJoystick(cx, cy, cx + dx * event.sensitivity, cy + dy * event.sensitivity)
                    true
                } else if (motion.action == MotionEvent.ACTION_UP || motion.action == MotionEvent.ACTION_CANCEL) {
                    if (event.action == ControlAction.SPAM) { spam = false; handler.removeCallbacks(spamRunnable) }
                    true
                } else true
            }
            windowManager.addView(controlView, params)
            profileControls.add(controlView to params)
            profileViewEvents[controlView] = event
        }
    }

    private fun dispatchTapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, GESTURE_DURATION_MS)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun dispatchHoldAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 450L)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun dispatchJoystick(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    // ── Drag-to-move for the floating menu ──────────────────────────────────

    private fun setupMenuDrag(view: View, params: WindowManager.LayoutParams) {
        var startX = 0f; var startY = 0f
        var initParamX = 0; var initParamY = 0
        var isDragging = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initParamX = params.x; initParamY = params.y
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startX
                    val dy = event.rawY - startY
                    if (!isDragging && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = (initParamX + dx).roundToInt()
                        params.y = (initParamY + dy).roundToInt()
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> isDragging   // consumed if drag, else click
                else -> false
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Click Points
    // ════════════════════════════════════════════════════════════════════════

    fun addClickPoint() {
        val index = clickPoints.size + 1

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.layout_click_point, null)
        view.findViewById<TextView>(R.id.tvIndex).text = index.toString()

        // Stagger new points so they don't stack exactly on top of each other
        val offset = (index - 1) * dpToPx(70)
        val params = buildOverlayParams(
            width  = dpToPx(60),
            height = dpToPx(60),
            x      = dpToPx(80) + offset,
            y      = dpToPx(300)
        )

        setupClickPointDrag(view, params)
        windowManager.addView(view, params)
        clickPoints.add(Pair(view, params))

        Toast.makeText(
            this,
            getString(R.string.toast_point_added, index),
            Toast.LENGTH_SHORT
        ).show()
    }

    fun removeLastClickPoint() {
        if (clickPoints.isEmpty()) return
        val (view, _) = clickPoints.removeLast()
        windowManager.removeView(view)
        Toast.makeText(this, R.string.toast_point_removed, Toast.LENGTH_SHORT).show()
    }

    private fun setupClickPointDrag(view: View, params: WindowManager.LayoutParams) {
        var startX = 0f; var startY = 0f
        var initX = 0; var initY = 0

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initX = params.x; initY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (initX + event.rawX - startX).roundToInt()
                    params.y = (initY + event.rawY - startY).roundToInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Clicker Loop
    // ════════════════════════════════════════════════════════════════════════

    private fun toggleClickLoop(btn: ImageButton) {
        if (isRunning) {
            stopClickLoop()
            btn.setImageResource(R.drawable.ic_play)
        } else {
            if (clickPoints.isEmpty()) {
                Toast.makeText(this, R.string.toast_no_points, Toast.LENGTH_SHORT).show()
                return
            }
            startClickLoop()
            btn.setImageResource(R.drawable.ic_pause)
        }
    }

    private fun startClickLoop() {
        if (isRunning) return
        loopIndex = 0
        isRunning = true
        handler.postDelayed(clickRunnable, clickIntervalMs)
    }

    private fun stopClickLoop() {
        isRunning = false
        handler.removeCallbacks(clickRunnable)
        loopIndex = 0
    }

    /**
     * Dispatches a synthetic tap at the current click point's screen position.
     *
     * Key design decisions:
     *  • GestureDescription.StrokeDescription duration = GESTURE_DURATION_MS (1 ms):
     *    This makes the gesture appear as a pure tap, not a long-press.
     *  • dispatchGesture() is asynchronous and non-blocking — it does NOT pause the
     *    main thread or consume the user's real touch stream. The user can still
     *    walk/move/interact in their game at exactly the same time.
     *  • We advance loopIndex modulo the list size so all points are hit in rotation.
     */
    private fun dispatchNextClick() {
        if (clickPoints.isEmpty()) return

        loopIndex = loopIndex % clickPoints.size
        val (view, params) = clickPoints[loopIndex]
        loopIndex = (loopIndex + 1) % clickPoints.size

        // Calculate screen-center of the click point view
        val cx = (params.x + view.width  / 2).toFloat()
        val cy = (params.y + view.height / 2).toFloat()

        val path = Path().apply { moveTo(cx, cy) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, GESTURE_DURATION_MS)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, null, null)
    }

    // ════════════════════════════════════════════════════════════════════════
    // Settings Dialog
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Opens the speed dialog on the main (UI) thread via a TYPE_APPLICATION_OVERLAY
     * window, but using an AlertDialog for proper theming.
     *
     * The seekbar maps linearly:
     *   progress 0   → 40 ms  (fastest)
     *   progress 196 → 2000 ms (slowest)
     *   step = (2000 - 40) / 196 ≈ 10 ms per step
     */
    private fun openSettingsDialog() {
        handler.post {
            val dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_settings, null)

            val tvSpeed = dialogView.findViewById<TextView>(R.id.tvSpeedLabel)
            val tvCps   = dialogView.findViewById<TextView>(R.id.tvCpsLabel)
            val seekbar = dialogView.findViewById<android.widget.SeekBar>(R.id.seekbarSpeed)

            fun msToProgress(ms: Long): Int =
                ((ms - Prefs.MIN_INTERVAL_MS).toFloat() /
                    (Prefs.MAX_INTERVAL_MS - Prefs.MIN_INTERVAL_MS) * 196).roundToInt()

            fun progressToMs(p: Int): Long =
                (Prefs.MIN_INTERVAL_MS + p.toLong() *
                    (Prefs.MAX_INTERVAL_MS - Prefs.MIN_INTERVAL_MS) / 196)
                    .coerceIn(Prefs.MIN_INTERVAL_MS, Prefs.MAX_INTERVAL_MS)

            fun updateLabels(ms: Long) {
                tvSpeed.text = "${ms} ms"
                val cps = (1000f / ms)
                tvCps.text = if (cps >= 10f) "${cps.roundToInt()} clicks/sec"
                             else String.format("%.1f clicks/sec", cps)
            }

            seekbar.progress = msToProgress(clickIntervalMs)
            updateLabels(clickIntervalMs)

            seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    updateLabels(progressToMs(p))
                }
                override fun onStartTrackingTouch(sb: SeekBar) = Unit
                override fun onStopTrackingTouch(sb: SeekBar) = Unit
            })

            // Preset buttons
            fun setPreset(ms: Long) {
                seekbar.progress = msToProgress(ms)
                updateLabels(ms)
            }
            dialogView.findViewById<android.widget.Button>(R.id.btnPreset40) .setOnClickListener { setPreset(40L)  }
            dialogView.findViewById<android.widget.Button>(R.id.btnPreset100).setOnClickListener { setPreset(100L) }
            dialogView.findViewById<android.widget.Button>(R.id.btnPreset250).setOnClickListener { setPreset(250L) }
            dialogView.findViewById<android.widget.Button>(R.id.btnPreset500).setOnClickListener { setPreset(500L) }

            AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog)
                .setTitle(R.string.settings_title)
                .setView(dialogView)
                .setPositiveButton(R.string.settings_ok) { _, _ ->
                    val newMs = progressToMs(seekbar.progress)
                    clickIntervalMs = newMs
                    Prefs.setClickIntervalMs(this, newMs)
                    // If loop is running, the new interval takes effect on the next tick
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Helpers
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Builds a WindowManager.LayoutParams for an overlay view.
     *
     * FLAG_NOT_FOCUSABLE    — touch events are NOT intercepted by this window;
     *                         they pass through to whatever is beneath.
     * FLAG_NOT_TOUCH_MODAL  — (implied by NOT_FOCUSABLE) events outside the
     *                         overlay bounds go to the underlying window.
     * FLAG_LAYOUT_NO_LIMITS — allows the overlay to be dragged beyond screen edges.
     * FLAG_WATCH_OUTSIDE_TOUCH — not set; we don't need to snoop on global touches.
     *
     * TYPE_APPLICATION_OVERLAY is the only type allowed for overlays since API 26.
     */
    private fun buildOverlayParams(
        width: Int,
        height: Int,
        x: Int = 0,
        y: Int = 0
    ) = WindowManager.LayoutParams(
        width,
        height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).also {
        it.gravity = Gravity.TOP or Gravity.START
        it.x = x
        it.y = y
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return (dp * density).roundToInt()
    }

    private fun getVibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
    } catch (e: Exception) { null }

    private fun vibrate() {
        try {
            vibrator?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    it.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(30L)
                }
            }
        } catch (_: Exception) {}
    }

    private fun cleanup() {
        stopClickLoop()
        editorMode = false
        editorOverlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        editorOverlay = null
        instance = null

        // Remove all overlays safely
        try { menuView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        menuView = null

        clickPoints.forEach { (view, _) ->
            try { windowManager.removeView(view) } catch (_: Exception) {}
        }
        clickPoints.clear()
        profileControls.forEach { (view, _) ->
            try { windowManager.removeView(view) } catch (_: Exception) {}
        }
        profileControls.clear()
    }
}
