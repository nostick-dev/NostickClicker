# NostickClicker ProGuard Rules
# Copyright (c) 2024 NostickClicker. All rights reserved.

# ── Keep the AccessibilityService so the system can bind it ──────────────────
-keep class com.nostick.clicker.ClickerService { *; }

# ── Keep the Application class ───────────────────────────────────────────────
-keep class com.nostick.clicker.NostickApplication { *; }

# ── Keep MainActivity ────────────────────────────────────────────────────────
-keep class com.nostick.clicker.MainActivity { *; }

# ── Keep Prefs (accessed by name via reflection in some R8 paths) ────────────
-keep class com.nostick.clicker.Prefs { *; }

# ── Standard Android/Kotlin keep rules ───────────────────────────────────────
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends android.app.Activity
-keep public class * extends android.accessibilityservice.AccessibilityService

# ── Suppress notes for missing classes (R8 default suppressions) ─────────────
-dontnote kotlinx.**
-dontwarn kotlinx.**
