/*
 * NostickClicker — Auto Clicker
 * Copyright (c) 2024 NostickClicker. All rights reserved.
 *
 * This file is part of NostickClicker.
 * NostickClicker uses the AccessibilityService API solely to simulate automated
 * touch gestures as requested by the user. No personal data is collected,
 * stored, or transmitted. The app operates 100% offline.
 */

package com.nostick.clicker

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/**
 * Application entry point.
 * Registers the foreground-service notification channel on Android 8+ (Oreo+).
 */
class NostickApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                getString(R.string.notif_channel_id),
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW   // silent — no sound/vibration
            ).apply {
                description = "Keeps NostickClicker running while active."
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }
}
