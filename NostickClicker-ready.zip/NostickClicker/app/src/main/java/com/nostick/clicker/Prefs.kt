/*
 * NostickClicker — Auto Clicker
 * Copyright (c) 2024 NostickClicker. All rights reserved.
 */

package com.nostick.clicker

import android.content.Context
import android.content.SharedPreferences

/**
 * Lightweight wrapper around SharedPreferences.
 * Stores only user preferences (click interval, disclosure ack).
 * No personal data is ever written here.
 */
object Prefs {

    private const val FILE = "nostick_prefs"

    // Keys
    private const val KEY_DISCLOSURE_ACCEPTED = "disclosure_accepted"
    private const val KEY_CLICK_INTERVAL_MS   = "click_interval_ms"

    /** Minimum click interval enforced by the app: 40 ms */
    const val MIN_INTERVAL_MS = 40L

    /** Maximum click interval (slowest): 2 000 ms */
    const val MAX_INTERVAL_MS = 2_000L

    /** Default interval on first launch: 100 ms (~10 CPS) */
    const val DEFAULT_INTERVAL_MS = 100L

    private fun sp(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ── Disclosure ──────────────────────────────────────────────────────────

    fun isDisclosureAccepted(ctx: Context): Boolean =
        sp(ctx).getBoolean(KEY_DISCLOSURE_ACCEPTED, false)

    fun setDisclosureAccepted(ctx: Context) =
        sp(ctx).edit().putBoolean(KEY_DISCLOSURE_ACCEPTED, true).apply()

    // ── Click interval ───────────────────────────────────────────────────────

    fun getClickIntervalMs(ctx: Context): Long =
        sp(ctx).getLong(KEY_CLICK_INTERVAL_MS, DEFAULT_INTERVAL_MS)
            .coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)

    fun setClickIntervalMs(ctx: Context, ms: Long) =
        sp(ctx).edit()
            .putLong(KEY_CLICK_INTERVAL_MS, ms.coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS))
            .apply()
}
