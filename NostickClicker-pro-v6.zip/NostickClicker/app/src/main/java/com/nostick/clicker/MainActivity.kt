/*
 * NostickClicker — Auto Clicker
 * Copyright (c) 2024 NostickClicker. All rights reserved.
 *
 * MainActivity.kt
 * ───────────────
 * Entry point. Responsibilities:
 *
 *  1. On VERY FIRST launch: show the Prominent Disclosure Policy dialog
 *     BEFORE requesting any permissions (Google Play requirement).
 *
 *  2. Walk the user through the two required system permission steps:
 *       a. Enable the NostickClicker AccessibilityService.
 *       b. Grant "Display over other apps" (SYSTEM_ALERT_WINDOW).
 *
 *  3. Once both permissions are granted, a "Launch" button sends the user
 *     back to their last-used app. The floating menu is shown by the service.
 *
 *  4. onResume() re-checks permission status so cards update live after the
 *     user returns from System Settings.
 */

package com.nostick.clicker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    // ── View refs ────────────────────────────────────────────────────────────
    private lateinit var cardAccessibility : LinearLayout
    private lateinit var cardOverlay       : LinearLayout
    private lateinit var tvAccessStatus    : TextView
    private lateinit var tvOverlayStatus   : TextView
    private lateinit var iconAccessibility : ImageView
    private lateinit var iconOverlay       : ImageView
    private lateinit var btnLaunch         : Button

    // ════════════════════════════════════════════════════════════════════════
    // Lifecycle
    // ════════════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()

        // ── Step 1: Prominent Disclosure (first-launch only) ─────────────────
        if (!Prefs.isDisclosureAccepted(this)) {
            showDisclosureDialog()
        } else {
            requestNotificationPermissionIfNeeded()
        }

        setupCardClicks()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
    }

    // ════════════════════════════════════════════════════════════════════════
    // View binding
    // ════════════════════════════════════════════════════════════════════════

    private fun bindViews() {
        cardAccessibility = findViewById(R.id.cardAccessibility)
        cardOverlay       = findViewById(R.id.cardOverlay)
        tvAccessStatus    = findViewById(R.id.tvAccessibilityStatus)
        tvOverlayStatus   = findViewById(R.id.tvOverlayStatus)
        iconAccessibility = findViewById(R.id.iconAccessibility)
        iconOverlay       = findViewById(R.id.iconOverlay)
        btnLaunch         = findViewById(R.id.btnLaunch)

        btnLaunch.setOnClickListener { launchClicker() }
        findViewById<Button>(R.id.btnControlEditor).setOnClickListener {
            startActivity(Intent(this, ControlEditorActivity::class.java))
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Prominent Disclosure Dialog
    // (required by Google Play before any privileged permission request)
    // ════════════════════════════════════════════════════════════════════════

    private fun showDisclosureDialog() {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_disclosure, null)

        AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog)
            .setView(dialogView)
            // Positive: user accepts → mark as done → continue flow
            .setPositiveButton(R.string.disclosure_understand) { _, _ ->
                Prefs.setDisclosureAccepted(this)
                requestNotificationPermissionIfNeeded()
            }
            // Negative: user declines → exit the app
            .setNegativeButton(R.string.disclosure_exit) { _, _ ->
                finishAffinity()
            }
            // Non-cancelable: the user MUST make an explicit choice
            .setCancelable(false)
            .show()
    }

    // ════════════════════════════════════════════════════════════════════════
    // Permission Status
    // ════════════════════════════════════════════════════════════════════════

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        return enabled.any { it.id.contains(packageName) }
    }

    private fun isOverlayPermissionGranted(): Boolean =
        Settings.canDrawOverlays(this)

    private fun refreshPermissionStatus() {
        val accessOk = isAccessibilityEnabled()
        val overlayOk = isOverlayPermissionGranted()

        // Accessibility card
        if (accessOk) {
            tvAccessStatus.text = getString(R.string.status_enabled)
            tvAccessStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
            iconAccessibility.setColorFilter(
                ContextCompat.getColor(this, android.R.color.holo_green_light)
            )
        } else {
            tvAccessStatus.text = getString(R.string.status_not_enabled)
            tvAccessStatus.setTextColor(0xFFCF6679.toInt())
            iconAccessibility.clearColorFilter()
        }

        // Overlay card
        if (overlayOk) {
            tvOverlayStatus.text = getString(R.string.status_enabled)
            tvOverlayStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
            iconOverlay.setColorFilter(
                ContextCompat.getColor(this, android.R.color.holo_green_light)
            )
        } else {
            tvOverlayStatus.text = getString(R.string.status_not_enabled)
            tvOverlayStatus.setTextColor(0xFFCF6679.toInt())
            iconOverlay.clearColorFilter()
        }

        // Launch button state
        btnLaunch.isEnabled = accessOk && overlayOk
        btnLaunch.alpha     = if (accessOk && overlayOk) 1f else 0.45f
    }

    // ════════════════════════════════════════════════════════════════════════
    // Card Click Handlers → deep-link to system settings
    // ════════════════════════════════════════════════════════════════════════

    private fun setupCardClicks() {
        cardAccessibility.setOnClickListener {
            openAccessibilitySettings()
        }
        cardOverlay.setOnClickListener {
            openOverlaySettings()
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openOverlaySettings() {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Launch
    // ════════════════════════════════════════════════════════════════════════

    private fun launchClicker() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Please enable the Accessibility Service first.", Toast.LENGTH_SHORT).show()
            openAccessibilitySettings()
            return
        }
        if (!isOverlayPermissionGranted()) {
            Toast.makeText(this, "Please allow Display Over Other Apps first.", Toast.LENGTH_SHORT).show()
            openOverlaySettings()
            return
        }

        ClickerService.instance?.revealControls()
        // Minimize this activity so the user is taken back to their app.
        moveTaskToBack(true)
    }

    // ════════════════════════════════════════════════════════════════════════
    // Android 13+ Notification Permission
    // ════════════════════════════════════════════════════════════════════════

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                requestPermissions(
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    REQ_NOTIF
                )
            }
        }
    }

    companion object {
        private const val REQ_NOTIF = 42
    }
}
