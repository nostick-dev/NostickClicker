package com.nostick.clicker

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.UUID

class ControlEditorActivity : AppCompatActivity() {
    private lateinit var profile: ControlProfile
    private lateinit var controlsBox: LinearLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var profileNameInput: EditText
    private lateinit var profilePackageInput: EditText
    private lateinit var screenEventsCheck: CheckBox
    private lateinit var keyEventsCheck: CheckBox
    private val previewViews = mutableMapOf<Long, View>()
    private val purple = Color.rgb(187, 134, 252)
    private val dark = Color.rgb(18, 18, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profile = ProfileStore.load(this).firstOrNull()
            ?: ControlProfile(UUID.randomUUID().toString(), "New profile", "")
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(Color.TRANSPARENT)
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(8, 8, 8, 8)
            setBackgroundColor(0xDD311B45.toInt())
        }
        val add = button("＋ ${getString(R.string.add_control)}") { showAddMenu() }
        val saveTop = button(getString(R.string.save_profile)) { saveProfile() }
        val exit = button(getString(R.string.exit_editor)) { finish() }
        toolbar.addView(add, LinearLayout.LayoutParams(0, 52, 1f)); toolbar.addView(saveTop, LinearLayout.LayoutParams(0, 52, 1f)); toolbar.addView(exit, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(toolbar)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = getString(R.string.editor_title); textSize = 25f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
        }
        content.addView(title)
        val name = field(getString(R.string.profile_name), profile.name)
        val packageName = field(getString(R.string.profile_package), profile.packageName)
        profileNameInput = name; profilePackageInput = packageName
        content.addView(name); content.addView(packageName)
        val screen = CheckBox(this).apply { text = getString(R.string.enable_screen_events); isChecked = profile.screenEventsEnabled; setTextColor(Color.WHITE) }
        val keys = CheckBox(this).apply { text = getString(R.string.enable_key_events); isChecked = profile.keyEventsEnabled; setTextColor(Color.WHITE) }
        screenEventsCheck = screen; keyEventsCheck = keys
        content.addView(screen); content.addView(keys)
        val help = TextView(this).apply { text = getString(R.string.editor_help); setTextColor(Color.LTGRAY); setPadding(0, 8, 0, 14) }
        content.addView(help)
        val previewTitle = TextView(this).apply { text = getString(R.string.transparent_preview_hint); setTextColor(Color.WHITE); setPadding(0, 8, 0, 8) }
        content.addView(previewTitle)
        previewBox = FrameLayout(this).apply { setBackgroundColor(0x55311B45); minimumHeight = 260 }
        content.addView(previewBox, LinearLayout.LayoutParams(-1, 260))
        controlsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(controlsBox)
        profile.controls.forEach { addPreviewControl(it); addControlRow(it) }
        val addScreen = button(getString(R.string.add_screen_event)) { addEvent(ControlEventType.SCREEN) }
        val addKey = button(getString(R.string.add_key_event)) { showKeyboardPicker() }
        val addMove = button(getString(R.string.add_move_joystick)) { addEvent(ControlEventType.SCREEN, mutableListOf(), ControlWidget.MOVE_JOYSTICK) }
        val addCamera = button(getString(R.string.add_camera_joystick)) { addEvent(ControlEventType.SCREEN, mutableListOf(), ControlWidget.CAMERA_JOYSTICK) }
        content.addView(addScreen); content.addView(addKey)
        content.addView(addMove); content.addView(addCamera)
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun saveProfile() {
        profile.name = profileNameInput.text.toString().ifBlank { "Profile" }
        profile.packageName = profilePackageInput.text.toString().trim()
        profile.screenEventsEnabled = screenEventsCheck.isChecked
        profile.keyEventsEnabled = keyEventsCheck.isChecked
        ProfileStore.upsert(this, profile)
        Toast.makeText(this, R.string.profile_saved, Toast.LENGTH_SHORT).show()
    }

    private fun showAddMenu() {
        val options = arrayOf(getString(R.string.add_screen_event), getString(R.string.add_key_event), getString(R.string.add_move_joystick), getString(R.string.add_camera_joystick))
        AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog).setTitle(R.string.add_control).setItems(options) { _, which ->
            when (which) {
                0 -> addEvent(ControlEventType.SCREEN)
                1 -> showKeyboardPicker()
                2 -> addEvent(ControlEventType.SCREEN, mutableListOf(), ControlWidget.MOVE_JOYSTICK)
                3 -> addEvent(ControlEventType.SCREEN, mutableListOf(), ControlWidget.CAMERA_JOYSTICK)
            }
        }.show()
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setSingleLine(true); setPadding(0, 8, 0, 8)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.BLACK); setBackgroundColor(purple); setOnClickListener { action() }
    }

    private fun addEvent(type: ControlEventType, sequence: MutableList<String> = mutableListOf(), widget: ControlWidget = ControlWidget.BUTTON) {
        val label = when (widget) {
            ControlWidget.MOVE_JOYSTICK -> "Move joystick"
            ControlWidget.CAMERA_JOYSTICK -> "Camera joystick"
            ControlWidget.BUTTON -> if (type == ControlEventType.KEY) sequence.joinToString(" + ") else "Screen button"
        }
        val event = ControlEvent(System.nanoTime(), label, type, ControlAction.CLICK, widget, sequence)
        profile.controls.add(event); addPreviewControl(event); addControlRow(event)
    }

    private fun addPreviewControl(event: ControlEvent) {
        val view = TextView(this).apply {
            text = when (event.widget) {
                ControlWidget.BUTTON -> event.label
                ControlWidget.MOVE_JOYSTICK -> "MOVE"
                ControlWidget.CAMERA_JOYSTICK -> "CAM"
            }
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f
            setBackgroundColor(if (event.widget == ControlWidget.BUTTON) 0xCC6A1B9A.toInt() else 0x996A1B9A.toInt())
        }
        previewViews[event.id] = view
        previewBox.addView(view)
        view.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startLeft = 0; var startTop = 0
            var moved = false
            override fun onTouch(v: View, motion: android.view.MotionEvent): Boolean {
                val lp = v.layoutParams as FrameLayout.LayoutParams
                when (motion.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { downX = motion.rawX; downY = motion.rawY; startLeft = lp.leftMargin; startTop = lp.topMargin; moved = false }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        moved = true
                        lp.leftMargin = (startLeft + motion.rawX - downX).toInt().coerceIn(0, (previewBox.width - v.width).coerceAtLeast(0))
                        lp.topMargin = (startTop + motion.rawY - downY).toInt().coerceIn(0, (previewBox.height - v.height).coerceAtLeast(0))
                        v.layoutParams = lp
                    }
                    android.view.MotionEvent.ACTION_UP -> {
                        event.x = if (previewBox.width == 0) event.x else lp.leftMargin.toFloat() / previewBox.width
                        event.y = if (previewBox.height == 0) event.y else lp.topMargin.toFloat() / previewBox.height
                        if (!moved) showProperties(event)
                    }
                }
                return true
            }
        })
        previewBox.post { refreshPreview(event) }
    }

    private fun showProperties(event: ControlEvent) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 8) }
        val label = field(getString(R.string.control_label), event.label)
        val action = Spinner(this).apply {
            adapter = ArrayAdapter(this@ControlEditorActivity, android.R.layout.simple_spinner_dropdown_item, ControlAction.values().map { it.name })
            setSelection(event.action.ordinal)
        }
        val size = SeekBar(this).apply { max = 100; progress = (event.width * 200).toInt().coerceIn(12, 100) }
        box.addView(label); box.addView(TextView(this).apply { text = getString(R.string.event_mode); setTextColor(Color.LTGRAY) }); box.addView(action)
        box.addView(TextView(this).apply { text = getString(R.string.control_size); setTextColor(Color.LTGRAY) }); box.addView(size)
        AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog).setTitle(event.label).setView(box)
            .setPositiveButton(R.string.settings_ok) { _, _ ->
                event.label = label.text.toString().ifBlank { event.label }
                event.action = ControlAction.values()[action.selectedItemPosition]
                val fraction = (size.progress.coerceAtLeast(12) / 200f).coerceIn(.06f, .5f)
                event.width = fraction; event.height = (fraction * .6f).coerceIn(.06f, .35f)
                refreshPreview(event)
            }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun refreshPreview(event: ControlEvent) {
        val view = previewViews[event.id] ?: return
        val width = (previewBox.width * event.width).toInt().coerceIn(56, (previewBox.width * .8f).toInt().coerceAtLeast(56))
        val height = (previewBox.height * event.height).toInt().coerceIn(42, (previewBox.height * .6f).toInt().coerceAtLeast(42))
        val lp = FrameLayout.LayoutParams(width, height)
        lp.leftMargin = (previewBox.width * event.x).toInt().coerceIn(0, (previewBox.width - width).coerceAtLeast(0))
        lp.topMargin = (previewBox.height * event.y).toInt().coerceIn(0, (previewBox.height - height).coerceAtLeast(0))
        view.layoutParams = lp
    }

    private fun addControlRow(event: ControlEvent) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundColor(Color.rgb(38, 30, 48)) }
        val title = TextView(this).apply { text = "${event.type.name}: ${event.label}"; textSize = 16f; setTextColor(Color.WHITE) }
        val action = Spinner(this).apply {
            adapter = ArrayAdapter(this@ControlEditorActivity, android.R.layout.simple_spinner_dropdown_item, ControlAction.values().map { it.name })
            setSelection(event.action.ordinal)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { event.action = ControlAction.values()[position] }
            }
        }
        val remove = button(getString(R.string.remove_event)) {
            profile.controls.remove(event); controlsBox.removeView(row)
            previewViews.remove(event.id)?.let { previewBox.removeView(it) }
        }
        val size = SeekBar(this).apply {
            max = 100; progress = (event.width.coerceIn(.06f, .5f) * 200f).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) {
                    val fraction = (value.coerceAtLeast(12) / 200f).coerceIn(.06f, .5f)
                    event.width = fraction; event.height = (fraction * .6f).coerceIn(.06f, .35f); refreshPreview(event)
                }
                override fun onStartTrackingTouch(sb: SeekBar) = Unit
                override fun onStopTrackingTouch(sb: SeekBar) = Unit
            })
        }
        row.addView(title); row.addView(action); row.addView(TextView(this).apply { text = getString(R.string.control_size); setTextColor(Color.LTGRAY) }); row.addView(size); row.addView(remove); controlsBox.addView(row)
    }

    private fun showKeyboardPicker() {
        val selected = mutableListOf<String>()
        val keys = listOf("CTRL", "ALT", "SHIFT", "TAB", "ESC", "ENTER", "SPACE", "BACKSPACE", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12") + ('A'..'Z').map { it.toString() }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12); setBackgroundColor(Color.rgb(50, 20, 70)) }
        val selectedText = TextView(this).apply { setTextColor(Color.WHITE); text = getString(R.string.selected_keys) }
        box.addView(selectedText)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keys.chunked(5).forEach { chunk ->
            val line = LinearLayout(this)
            chunk.forEach { key ->
                val b = Button(this).apply {
                    text = key; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(105, 45, 145))
                    setOnClickListener { selected.add(key); selectedText.text = getString(R.string.selected_keys) + selected.joinToString(" + ") }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 52, 1f))
            }
            grid.addView(line)
        }
        box.addView(grid)
        AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog).setTitle(R.string.keyboard_title).setView(box)
            .setPositiveButton(R.string.add_event) { _, _ -> if (selected.isNotEmpty()) addEvent(ControlEventType.KEY, selected.toMutableList()) }
            .setNegativeButton(android.R.string.cancel, null).show()
    }
}
