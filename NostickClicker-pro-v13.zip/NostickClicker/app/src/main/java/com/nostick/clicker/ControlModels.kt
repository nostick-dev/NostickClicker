package com.nostick.clicker

/** Types of virtual controls supported by the editor. */
enum class ControlEventType { SCREEN, KEY }
enum class ControlAction { CLICK, HOLD, TOGGLE, SPAM }
enum class ControlWidget { BUTTON, MOVE_JOYSTICK, CAMERA_JOYSTICK }

data class ControlEvent(
    val id: Long,
    var label: String,
    var type: ControlEventType,
    var action: ControlAction,
    var widget: ControlWidget = ControlWidget.BUTTON,
    var keySequence: MutableList<String> = mutableListOf(),
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var width: Float = 0.14f,
    var height: Float = 0.08f,
    var sensitivity: Float = 1f,
    var intervalMs: Long = 120L,
    var enabled: Boolean = true
)

data class ControlProfile(
    var id: String,
    var name: String,
    var packageName: String,
    var screenEventsEnabled: Boolean = true,
    var keyEventsEnabled: Boolean = false,
    var controls: MutableList<ControlEvent> = mutableListOf()
)
