package com.nostick.clicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ProfileStore {
    private const val PREFS = "control_profiles"
    private const val KEY = "profiles"

    fun load(context: Context): MutableList<ControlProfile> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            MutableList(array.length()) { index -> fromJson(array.getJSONObject(index)) }
        }.getOrDefault(mutableListOf())
    }

    fun save(context: Context, profiles: List<ControlProfile>) {
        val array = JSONArray()
        profiles.forEach { array.put(toJson(it)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    fun upsert(context: Context, profile: ControlProfile) {
        val profiles = load(context)
        val index = profiles.indexOfFirst { it.id == profile.id }
        if (index >= 0) profiles[index] = profile else profiles.add(profile)
        save(context, profiles)
    }

    private fun toJson(profile: ControlProfile) = JSONObject().apply {
        put("id", profile.id)
        put("name", profile.name)
        put("packageName", profile.packageName)
        put("screenEventsEnabled", profile.screenEventsEnabled)
        put("keyEventsEnabled", profile.keyEventsEnabled)
        put("controls", JSONArray().also { array -> profile.controls.forEach { array.put(eventJson(it)) } })
    }

    private fun eventJson(event: ControlEvent) = JSONObject().apply {
        put("id", event.id); put("label", event.label)
        put("type", event.type.name); put("action", event.action.name)
        put("keys", JSONArray(event.keySequence))
        put("x", event.x); put("y", event.y)
        put("width", event.width); put("height", event.height)
        put("sensitivity", event.sensitivity); put("intervalMs", event.intervalMs)
        put("enabled", event.enabled)
    }

    private fun fromJson(json: JSONObject): ControlProfile {
        val controls = mutableListOf<ControlEvent>()
        val array = json.optJSONArray("controls") ?: JSONArray()
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val keys = mutableListOf<String>()
            val keyArray = item.optJSONArray("keys") ?: JSONArray()
            for (k in 0 until keyArray.length()) keys.add(keyArray.optString(k))
            controls.add(ControlEvent(
                id = item.optLong("id", System.nanoTime()),
                label = item.optString("label", "Control"),
                type = runCatching { ControlEventType.valueOf(item.optString("type")) }.getOrDefault(ControlEventType.SCREEN),
                action = runCatching { ControlAction.valueOf(item.optString("action")) }.getOrDefault(ControlAction.CLICK),
                keySequence = keys,
                x = item.optDouble("x", .5).toFloat(), y = item.optDouble("y", .5).toFloat(),
                width = item.optDouble("width", .14).toFloat(), height = item.optDouble("height", .08).toFloat(),
                sensitivity = item.optDouble("sensitivity", 1.0).toFloat(),
                intervalMs = item.optLong("intervalMs", 120), enabled = item.optBoolean("enabled", true)
            ))
        }
        return ControlProfile(
            id = json.optString("id", "default"), name = json.optString("name", "Default"),
            packageName = json.optString("packageName", ""),
            screenEventsEnabled = json.optBoolean("screenEventsEnabled", true),
            keyEventsEnabled = json.optBoolean("keyEventsEnabled", false), controls = controls
        )
    }
}
