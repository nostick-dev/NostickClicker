package com.nostick.clicker

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.UUID

class ControlEditorActivity : AppCompatActivity() {
    private lateinit var profile: ControlProfile
    private lateinit var controlsBox: LinearLayout
    private val purple = Color.rgb(187, 134, 252)
    private val dark = Color.rgb(18, 18, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profile = ProfileStore.load(this).firstOrNull()
            ?: ControlProfile(UUID.randomUUID().toString(), "New profile", "")
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(dark)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = getString(R.string.editor_title); textSize = 25f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
        }
        content.addView(title)
        val name = field(getString(R.string.profile_name), profile.name)
        val packageName = field(getString(R.string.profile_package), profile.packageName)
        content.addView(name); content.addView(packageName)
        val screen = CheckBox(this).apply { text = getString(R.string.enable_screen_events); isChecked = profile.screenEventsEnabled; setTextColor(Color.WHITE) }
        val keys = CheckBox(this).apply { text = getString(R.string.enable_key_events); isChecked = profile.keyEventsEnabled; setTextColor(Color.WHITE) }
        content.addView(screen); content.addView(keys)
        val help = TextView(this).apply { text = getString(R.string.editor_help); setTextColor(Color.LTGRAY); setPadding(0, 8, 0, 14) }
        content.addView(help)
        controlsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(controlsBox)
        profile.controls.forEach { addControlRow(it) }
        val addScreen = button(getString(R.string.add_screen_event)) { addEvent(ControlEventType.SCREEN) }
        val addKey = button(getString(R.string.add_key_event)) { showKeyboardPicker() }
        content.addView(addScreen); content.addView(addKey)
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val save = button(getString(R.string.save_profile)) {
            profile.name = name.text.toString().ifBlank { "Profile" }
            profile.packageName = packageName.text.toString().trim()
            profile.screenEventsEnabled = screen.isChecked; profile.keyEventsEnabled = keys.isChecked
            ProfileStore.upsert(this, profile)
            Toast.makeText(this, R.string.profile_saved, Toast.LENGTH_SHORT).show()
        }
        root.addView(save); setContentView(root)
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setSingleLine(true); setPadding(0, 8, 0, 8)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.BLACK); setBackgroundColor(purple); setOnClickListener { action() }
    }

    private fun addEvent(type: ControlEventType, sequence: MutableList<String> = mutableListOf()) {
        val event = ControlEvent(System.nanoTime(), if (type == ControlEventType.KEY) sequence.joinToString(" + ") else "Screen button", type, ControlAction.CLICK, sequence)
        profile.controls.add(event); addControlRow(event)
    }

    private fun addControlRow(event: ControlEvent) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundColor(Color.rgb(38, 30, 48)) }
        val title = TextView(this).apply { text = "${event.type.name}: ${event.label}"; textSize = 16f; setTextColor(Color.WHITE) }
        val action = Spinner(this).apply {
            adapter = ArrayAdapter(this@ControlEditorActivity, android.R.layout.simple_spinner_dropdown_item, ControlAction.values().map { it.name })
            setSelection(event.action.ordinal)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { event.action = ControlAction.values()[position] }
            }
        }
        val remove = button(getString(R.string.remove_event)) { profile.controls.remove(event); controlsBox.removeView(row) }
        row.addView(title); row.addView(action); row.addView(remove); controlsBox.addView(row)
    }

    private fun showKeyboardPicker() {
        val selected = mutableListOf<String>()
        val keys = listOf("CTRL", "ALT", "SHIFT", "TAB", "ESC", "ENTER", "SPACE", "BACKSPACE", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12") + ('A'..'Z').map { it.toString() }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12); setBackgroundColor(Color.rgb(50, 20, 70)) }
        val selectedText = TextView(this).apply { setTextColor(Color.WHITE); text = getString(R.string.selected_keys) }
        box.addView(selectedText)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keys.chunked(5).forEach { chunk ->
            val line = LinearLayout(this)
            chunk.forEach { key ->
                val b = Button(this).apply {
                    text = key; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(105, 45, 145))
                    setOnClickListener { selected.add(key); selectedText.text = getString(R.string.selected_keys) + selected.joinToString(" + ") }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 52, 1f))
            }
            grid.addView(line)
        }
        box.addView(grid)
        AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog).setTitle(R.string.keyboard_title).setView(box)
            .setPositiveButton(R.string.add_event) { _, _ -> if (selected.isNotEmpty()) addEvent(ControlEventType.KEY, selected.toMutableList()) }
            .setNegativeButton(android.R.string.cancel, null).show()
    }
}
