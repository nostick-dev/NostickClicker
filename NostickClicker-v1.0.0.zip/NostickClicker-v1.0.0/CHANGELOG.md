# Changelog

## 1.0.0 — Official release
- Sequential auto-clicker with draggable numbered click points, 40–2000 ms speed
  and an optional "stop after N clicks" limit.
- Floating menu (play/pause, add/remove point, speed, layout editor, minimize,
  close) that adapts to portrait and landscape.
- Profiles with on-screen buttons (tap / hold / toggle / spam), system buttons
  (back / home / recents) and Move / Look joysticks.
- Every control acts on its own target point; a target placed over another
  control passes the touch through to the game.
- Classic locked joystick: the white thumb stays fully inside the base.
- Built-in multi-touch engine, plus optional Shizuku mode for real, uninterrupted
  multi-touch.
- Arabic (RTL) and English, dark theme, adaptive + themed launcher icon.
- 100% offline, no Internet permission.
