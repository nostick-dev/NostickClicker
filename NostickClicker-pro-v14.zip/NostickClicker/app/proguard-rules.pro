# NostickClicker ProGuard / R8 rules
# The accessibility service is bound by name from the manifest.
-keep class com.nostick.clicker.ClickerService { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends android.accessibilityservice.AccessibilityService
