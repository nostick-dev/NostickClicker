/*
 * NostickClicker — Auto Clicker
 * Copyright (c) 2026 NostickClicker. All rights reserved.
 *
 * ClickerService.kt
 * ─────────────────
 * AccessibilityService that owns every floating window of the app:
 *
 *  • the floating menu (play / points / speed / layout editor / hide / close)
 *  • draggable click points used by the sequential auto-clicker
 *  • on-screen profile controls (buttons and joysticks) and their editor
 *
 * The service never reads screen content and never touches the network. It only
 * injects the gestures the user asked for through dispatchGesture().
 */
package com.nostick.clicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

class ClickerService : AccessibilityService() {

    companion object {
        /** Non-null while the service is connected. */
        @Volatile
        var instance: ClickerService? = null
            private set

        private const val TAP_MS = 12L
        private const val STEP_MS = 30L
        private const val MAX_POINTS = 20
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    }

    // ── Infrastructure ───────────────────────────────────────────────────────
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val handler = Handler(Looper.getMainLooper())
    private var vibrator: Vibrator? = null
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    /** False after the user pressed Close: every overlay is removed until showAll(). */
    private var overlaysEnabled = true

    // ── Floating menu ────────────────────────────────────────────────────────
    private var menuView: LinearLayout? = null
    private var menuParams: WindowManager.LayoutParams? = null
    private var playButton: ImageButton? = null
    private var speedLabel: TextView? = null
    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var menuMinimized = false

    // ── Click points + loop ──────────────────────────────────────────────────
    private class ClickPoint(val view: View, val params: WindowManager.LayoutParams)

    private val clickPoints = mutableListOf<ClickPoint>()
    private var isRunning = false
    private var intervalMs = Prefs.DEFAULT_INTERVAL_MS
    private var maxClicks = 0
    private var clickCount = 0
    private var loopIndex = 0
    private val tickRunnable = Runnable { tick() }

    // ── Panels / editor / profile controls ───────────────────────────────────
    private var panelRoot: View? = null
    private var editorBar: View? = null
    private var profileChip: TextView? = null
    private var editorMode = false
    private var activeProfile: ControlProfile? = null
    private val controlViews = mutableListOf<ControlView>()

    // ════════════════════════════════════════════════════════════════════════
    // Lifecycle
    // ════════════════════════════════════════════════════════════════════════

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        vibrator = getVibrator()
        intervalMs = Prefs.getClickIntervalMs(this)
        maxClicks = Prefs.getMaxClicks(this)
        activeProfile = loadActiveProfile()
        showAll()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    /** Required by AccessibilityService; NostickClicker does not process events. */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotation changes the screen size: rebuild everything that depends on it.
        handler.post { rebuildAfterRotation() }
    }

    private fun cleanup() {
        stopClicking()
        closePanel()
        removeEditorBar()
        editorMode = false
        removeBubble()
        removeMenu()
        clearPoints()
        clearControls()
        instance = null
    }

    // ════════════════════════════════════════════════════════════════════════
    // Public API (used by the activities)
    // ════════════════════════════════════════════════════════════════════════

    fun showAll() {
        overlaysEnabled = true
        menuMinimized = false
        removeBubble()
        showMenu()
        if (editorMode) menuView?.visibility = View.GONE
        rebuildControls()
    }

    fun hideAll() {
        stopClicking()
        closePanel()
        removeEditorBar()
        editorMode = false
        removeBubble()
        removeMenu()
        clearPoints()
        clearControls()
        overlaysEnabled = false
    }

    fun isShowing(): Boolean = overlaysEnabled

    fun activeProfileId(): String = activeProfile?.id ?: ""

    /** Switches the on-screen controls to the saved profile with [id]. */
    fun activateProfile(id: String) {
        val profile = ProfileStore.find(this, id) ?: return
        activeProfile = profile
        Prefs.setActiveProfileId(this, id)
        profileChip?.text = profile.name
        rebuildControls()
    }

    /** Re-reads the active profile from disk (after the app edited it). */
    fun reloadActiveProfile() {
        val id = activeProfile?.id ?: return
        val fresh = ProfileStore.find(this, id)
        if (fresh == null) {
            activeProfile = loadActiveProfile()
        } else {
            activeProfile = fresh
        }
        rebuildControls()
    }

    fun openEditor() {
        if (!overlaysEnabled) showAll()
        enterEditor()
    }

    private fun loadActiveProfile(): ControlProfile {
        val list = ProfileStore.load(this)
        if (list.isEmpty()) {
            val p = ControlProfile(UUID.randomUUID().toString(), getString(R.string.default_profile_name, 1), "")
            ProfileStore.upsert(this, p)
            Prefs.setActiveProfileId(this, p.id)
            return p
        }
        val id = Prefs.getActiveProfileId(this)
        return list.firstOrNull { it.id == id } ?: list.first()
    }

    // ════════════════════════════════════════════════════════════════════════
    // Overlay helpers
    // ════════════════════════════════════════════════════════════════════════

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun screenSize(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            p.set(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
        }
        return p
    }

    private fun isLandscape(): Boolean {
        val s = screenSize()
        return s.x > s.y
    }

    /**
     * FLAG_LAYOUT_IN_SCREEN makes x/y absolute screen coordinates.
     * FLAG_NOT_TOUCH_MODAL lets touches outside the window reach the app below.
     */
    private fun overlayParams(
        w: Int,
        h: Int,
        x: Int = 0,
        y: Int = 0,
        touchable: Boolean = true,
        focusable: Boolean = false
    ): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            it.x = x
            it.y = y
            if (focusable) it.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
    }

    private fun addOverlay(view: View, params: WindowManager.LayoutParams): Boolean =
        try {
            wm.addView(view, params)
            true
        } catch (e: Exception) {
            false
        }

    private fun removeOverlay(view: View?) {
        if (view == null) return
        try {
            wm.removeView(view)
        } catch (_: Exception) {
        }
    }

    private fun updateOverlay(view: View, params: WindowManager.LayoutParams) {
        try {
            wm.updateViewLayout(view, params)
        } catch (_: Exception) {
        }
    }

    private fun clampParams(view: View, p: WindowManager.LayoutParams) {
        val s = screenSize()
        val w = if (view.width > 0) view.width else if (p.width > 0) p.width else 0
        val h = if (view.height > 0) view.height else if (p.height > 0) p.height else 0
        p.x = p.x.coerceIn(0, (s.x - w).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (s.y - h).coerceAtLeast(0))
    }

    private fun clampToScreen(view: View, p: WindowManager.LayoutParams) {
        clampParams(view, p)
        updateOverlay(view, p)
    }

    private fun centerOf(view: View): FloatArray {
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return floatArrayOf(loc[0] + view.width / 2f, loc[1] + view.height / 2f)
    }

    /** Drag [handle] to move [target]. A touch without movement calls [onTap]. */
    private fun attachDrag(
        handle: View,
        target: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragged = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragged && (abs(dx) > touchSlop || abs(dy) > touchSlop)) dragged = true
                    if (dragged) {
                        params.x = (startX + dx).roundToInt()
                        params.y = (startY + dy).roundToInt()
                        clampParams(target, params)
                        updateOverlay(target, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) onTap?.invoke()
                }
            }
            true
        }
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun haptic() {
        try {
            vibrator?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    it.vibrate(VibrationEffect.createOneShot(25L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(25L)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun getVibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
    } catch (e: Exception) {
        null
    }

    // ════════════════════════════════════════════════════════════════════════
    // Gestures
    // ════════════════════════════════════════════════════════════════════════

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, TAP_MS)
        try {
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        } catch (_: Exception) {
        }
    }

    /**
     * One finger that stays down: used for HOLD and for joysticks. The stroke is
     * continued in short segments so it can follow the finger without lifting.
     */
    private inner class StrokeSession {
        private var stroke: GestureDescription.StrokeDescription? = null
        private var lastX = 0f
        private var lastY = 0f
        private var pendingX = 0f
        private var pendingY = 0f
        private var hasPending = false
        private var finishing = false
        var active = false
            private set

        fun start(x: Float, y: Float) {
            active = true
            finishing = false
            hasPending = false
            stroke = null
            lastX = x
            lastY = y
            send(x, y, true)
        }

        fun moveTo(x: Float, y: Float) {
            if (!active) return
            pendingX = x
            pendingY = y
            hasPending = true
        }

        fun end() {
            if (!active) return
            finishing = true
        }

        fun cancel() {
            active = false
            finishing = false
            hasPending = false
            stroke = null
        }

        private fun next() {
            if (!active) return
            val tx = if (hasPending) pendingX else lastX
            val ty = if (hasPending) pendingY else lastY
            hasPending = false
            send(tx, ty, !finishing)
        }

        private fun send(x: Float, y: Float, willContinue: Boolean) {
            val path = Path().apply {
                moveTo(lastX, lastY)
                if (x != lastX || y != lastY) lineTo(x, y)
            }
            val previous = stroke
            val s = try {
                if (previous == null) {
                    GestureDescription.StrokeDescription(path, 0L, STEP_MS, willContinue)
                } else {
                    previous.continueStroke(path, 0L, STEP_MS, willContinue)
                }
            } catch (e: Exception) {
                cancel()
                return
            }
            stroke = s
            lastX = x
            lastY = y
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (!active) return
                    if (!willContinue) {
                        active = false
                        stroke = null
                    } else {
                        next()
                    }
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    cancel()
                }
            }
            val ok = try {
                dispatchGesture(GestureDescription.Builder().addStroke(s).build(), callback, null)
            } catch (e: Exception) {
                false
            }
            if (!ok) cancel()
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Floating menu
    // ════════════════════════════════════════════════════════════════════════

    private fun menuBackground(running: Boolean) =
        Ui.rounded(
            this, Ui.OVERLAY_BG, 26,
            if (running) Ui.ACCENT else Ui.STROKE,
            if (running) 2 else 1
        )

    private fun showMenu() {
        if (menuView != null || menuMinimized || !overlaysEnabled) return
        val params = menuParams ?: overlayParams(WRAP, WRAP, dp(12), dp(110))
        menuParams = params
        val view = buildMenu(params)
        if (addOverlay(view, params)) {
            menuView = view
            updateMenuState()
            view.post { menuView?.let { clampToScreen(it, params) } }
        }
    }

    private fun removeMenu() {
        removeOverlay(menuView)
        menuView = null
        playButton = null
        speedLabel = null
    }

    private fun buildMenu(params: WindowManager.LayoutParams): LinearLayout {
        val horizontal = isLandscape()
        val root = LinearLayout(this).apply {
            orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = menuBackground(false)
        }

        fun slot(size: Int) = LinearLayout.LayoutParams(dp(size), dp(size)).apply {
            setMargins(dp(1), dp(1), dp(1), dp(1))
        }

        fun divider(): View = View(this).apply { setBackgroundColor(Ui.STROKE) }
        fun dividerLp() =
            if (horizontal) LinearLayout.LayoutParams(dp(1), dp(24)).apply { setMargins(dp(4), 0, dp(4), 0) }
            else LinearLayout.LayoutParams(dp(24), dp(1)).apply { setMargins(0, dp(4), 0, dp(4)) }

        // Drag handle
        val handle = FrameLayout(this)
        val grip = View(this).apply { background = Ui.rounded(this@ClickerService, Ui.STROKE, 2) }
        handle.addView(
            grip,
            FrameLayout.LayoutParams(
                if (horizontal) dp(4) else dp(26),
                if (horizontal) dp(26) else dp(4),
                Gravity.CENTER
            )
        )
        root.addView(
            handle,
            LinearLayout.LayoutParams(
                if (horizontal) dp(18) else dp(44),
                if (horizontal) dp(44) else dp(18)
            )
        )
        attachDrag(handle, root, params)

        // Play / pause
        val play = ImageButton(this).apply {
            setImageResource(R.drawable.ic_play)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = Ui.ripple(this@ClickerService, Ui.gradient(this@ClickerService, circle = true), circle = true)
            contentDescription = getString(R.string.btn_play_pause)
            setOnClickListener {
                haptic()
                toggleClicking()
            }
        }
        playButton = play
        root.addView(play, slot(46))

        val label = Ui.text(this, "", 10f, Ui.MUTED, true).apply { gravity = Gravity.CENTER }
        speedLabel = label
        root.addView(
            label,
            LinearLayout.LayoutParams(WRAP, WRAP).apply {
                if (horizontal) marginStart = dp(4) else topMargin = dp(2)
            }
        )

        root.addView(divider(), dividerLp())

        fun icon(res: Int, desc: Int, tint: Int = Ui.TEXT, onClick: () -> Unit) {
            val b = Ui.iconButton(this, res, tint, 40) {
                haptic()
                onClick()
            }
            b.contentDescription = getString(desc)
            root.addView(b, slot(40))
        }

        icon(R.drawable.ic_add, R.string.btn_add) { addClickPoint() }
        icon(R.drawable.ic_remove, R.string.btn_remove) { removeLastClickPoint() }
        icon(R.drawable.ic_speed, R.string.btn_speed) { showSpeedPanel() }
        icon(R.drawable.ic_edit, R.string.btn_editor) { enterEditor() }
        root.addView(divider(), dividerLp())
        icon(R.drawable.ic_minimize, R.string.btn_minimize) { minimizeMenu() }
        icon(R.drawable.ic_close, R.string.btn_close, Ui.DANGER) { closeAll() }
        return root
    }

    private fun updateMenuState() {
        playButton?.setImageResource(if (isRunning) R.drawable.ic_pause else R.drawable.ic_play)
        speedLabel?.text = getString(R.string.ms_fmt, intervalMs)
        menuView?.background = menuBackground(isRunning)
    }

    private fun minimizeMenu() {
        closePanel()
        menuMinimized = true
        removeMenu()
        showBubble()
    }

    private fun showBubble() {
        if (bubbleView != null || !overlaysEnabled) return
        val size = dp(46)
        val params = bubbleParams ?: overlayParams(size, size, menuParams?.x ?: dp(12), menuParams?.y ?: dp(110))
        bubbleParams = params
        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_cursor)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = Ui.ripple(this@ClickerService, Ui.gradient(this@ClickerService, circle = true), circle = true)
            alpha = 0.92f
            contentDescription = getString(R.string.btn_restore_menu)
        }
        attachDrag(view, view, params) { restoreMenu() }
        if (addOverlay(view, params)) {
            bubbleView = view
            view.post { bubbleView?.let { clampToScreen(it, params) } }
        }
    }

    private fun removeBubble() {
        removeOverlay(bubbleView)
        bubbleView = null
    }

    private fun restoreMenu() {
        val bp = bubbleParams
        val mp = menuParams
        if (bp != null && mp != null) {
            mp.x = bp.x
            mp.y = bp.y
        }
        menuMinimized = false
        removeBubble()
        showMenu()
    }

    private fun closeAll() {
        hideAll()
        toast(R.string.toast_closed)
    }

    // ════════════════════════════════════════════════════════════════════════
    // Click points + loop
    // ════════════════════════════════════════════════════════════════════════

    fun addClickPoint() {
        if (clickPoints.size >= MAX_POINTS) {
            toast(R.string.toast_max_points)
            return
        }
        val index = clickPoints.size + 1
        val view = LayoutInflater.from(this).inflate(R.layout.layout_click_point, null)
        view.findViewById<TextView>(R.id.tvIndex).text = index.toString()
        val s = screenSize()
        val size = dp(52)
        val offset = ((index - 1) % 6) * dp(22)
        val params = overlayParams(
            size, size,
            s.x / 2 - size / 2 + offset,
            s.y / 2 - size / 2 + offset,
            touchable = !isRunning
        )
        attachDrag(view, view, params)
        if (addOverlay(view, params)) {
            clickPoints.add(ClickPoint(view, params))
            toast(R.string.toast_point_added)
        }
    }

    fun removeLastClickPoint() {
        if (clickPoints.isEmpty()) return
        // removeAt(lastIndex) instead of removeLast(): the latter crashes on Android < 15.
        val point = clickPoints.removeAt(clickPoints.lastIndex)
        removeOverlay(point.view)
        if (clickPoints.isEmpty() && isRunning) stopClicking()
        toast(R.string.toast_point_removed)
    }

    private fun clearPoints() {
        clickPoints.forEach { removeOverlay(it.view) }
        clickPoints.clear()
    }

    private fun setPointsTouchable(touchable: Boolean) {
        clickPoints.forEach { point ->
            // A touchable overlay would swallow the injected tap instead of the app below.
            point.params.flags = if (touchable) {
                point.params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                point.params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            point.view.alpha = if (touchable) 1f else 0.55f
            updateOverlay(point.view, point.params)
        }
    }

    private fun toggleClicking() {
        if (isRunning) stopClicking() else startClicking()
    }

    private fun startClicking() {
        if (isRunning) return
        if (clickPoints.isEmpty()) {
            toast(R.string.toast_no_points)
            return
        }
        isRunning = true
        loopIndex = 0
        clickCount = 0
        setPointsTouchable(false)
        updateMenuState()
        handler.postDelayed(tickRunnable, 200L)
    }

    private fun stopClicking() {
        val wasRunning = isRunning
        isRunning = false
        handler.removeCallbacks(tickRunnable)
        if (wasRunning) setPointsTouchable(true)
        updateMenuState()
    }

    private fun tick() {
        if (!isRunning) return
        if (clickPoints.isEmpty()) {
            stopClicking()
            return
        }
        loopIndex %= clickPoints.size
        val point = clickPoints[loopIndex]
        loopIndex = (loopIndex + 1) % clickPoints.size
        val c = centerOf(point.view)
        tapAt(c[0], c[1])
        pulse(point.view)
        clickCount++
        if (maxClicks > 0 && clickCount >= maxClicks) {
            stopClicking()
            Toast.makeText(this, getString(R.string.toast_finished, clickCount), Toast.LENGTH_SHORT).show()
            return
        }
        handler.postDelayed(tickRunnable, intervalMs)
    }

    private fun pulse(v: View) {
        v.animate().cancel()
        v.scaleX = 0.8f
        v.scaleY = 0.8f
        v.animate().scaleX(1f).scaleY(1f).setDuration(min(intervalMs, 140L)).start()
    }

    // ════════════════════════════════════════════════════════════════════════
    // Panels
    // ════════════════════════════════════════════════════════════════════════

    private fun showPanel(content: View, focusable: Boolean) {
        closePanel()
        val s = screenSize()
        val scrim = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            isClickable = true
            setOnClickListener { closePanel() }
        }
        val scroll = ScrollView(this).apply { addView(content) }
        scrim.addView(
            scroll,
            FrameLayout.LayoutParams(min(s.x - dp(32), dp(360)), WRAP, Gravity.CENTER)
        )
        val params = overlayParams(MATCH, MATCH, 0, 0, focusable = focusable)
        if (focusable) {
            scrim.isFocusableInTouchMode = true
            scrim.setOnKeyListener { _, code, event ->
                if (code == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    closePanel()
                    true
                } else {
                    false
                }
            }
        }
        if (addOverlay(scrim, params)) {
            panelRoot = scrim
            if (focusable) scrim.requestFocus()
        }
    }

    private fun closePanel() {
        removeOverlay(panelRoot)
        panelRoot = null
    }

    private fun cpsText(ms: Long): String {
        val cps = 1000f / ms
        val shown = if (cps >= 10f) cps.roundToInt().toString() else String.format(Locale.US, "%.1f", cps)
        return getString(R.string.cps_fmt, shown)
    }

    private fun showSpeedPanel() {
        var ms = intervalMs
        var limit = maxClicks

        val card = Ui.card(this).apply { isClickable = true }
        card.addView(Ui.text(this, getString(R.string.settings_title), 18f, Ui.TEXT, true))
        val valueView = Ui.text(this, "", 34f, Ui.ACCENT, true)
        val subView = Ui.text(this, "", 13f, Ui.MUTED)
        card.addView(valueView, Ui.lp(this, top = 10))
        card.addView(subView, Ui.lp(this, bottom = 6))

        val seek = SeekBar(this)
        Ui.styleSeekBar(seek)
        seek.max = ((Prefs.MAX_INTERVAL_MS - Prefs.MIN_INTERVAL_MS) / 10L).toInt()
        seek.progress = ((ms - Prefs.MIN_INTERVAL_MS) / 10L).toInt()
        card.addView(seek, Ui.lp(this, bottom = 8))

        val presets = listOf(40L, 100L, 250L, 500L, 1000L)
        val presetChips = mutableListOf<Pair<Long, TextView>>()
        val limits = listOf(0, 50, 100, 500, 1000)
        val limitChips = mutableListOf<Pair<Int, TextView>>()

        fun refresh() {
            valueView.text = getString(R.string.ms_fmt, ms)
            subView.text = cpsText(ms)
            presetChips.forEach { (v, tv) -> Ui.styleChip(tv, v == ms) }
            limitChips.forEach { (v, tv) -> Ui.styleChip(tv, v == limit) }
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                ms = Prefs.MIN_INTERVAL_MS + progress * 10L
                refresh()
            }

            override fun onStartTrackingTouch(bar: SeekBar) = Unit
            override fun onStopTrackingTouch(bar: SeekBar) = Unit
        })

        val presetRow = LinearLayout(this)
        presets.forEach { v ->
            val chip = Ui.chip(this, v.toString(), v == ms, 4) {
                ms = v
                seek.progress = ((v - Prefs.MIN_INTERVAL_MS) / 10L).toInt()
                refresh()
            }
            presetChips.add(v to chip)
            presetRow.addView(chip, Ui.lp(this, w = 0, weight = 1f, end = 6))
        }
        card.addView(presetRow)

        card.addView(Ui.text(this, getString(R.string.stop_after), 13f, Ui.MUTED), Ui.lp(this, top = 14, bottom = 6))
        val limitRow = LinearLayout(this)
        limits.forEach { v ->
            val chip = Ui.chip(this, if (v == 0) "∞" else v.toString(), v == limit, 4) {
                limit = v
                refresh()
            }
            limitChips.add(v to chip)
            limitRow.addView(chip, Ui.lp(this, w = 0, weight = 1f, end = 6))
        }
        card.addView(limitRow)

        val actions = LinearLayout(this)
        actions.addView(
            Ui.button(this, getString(android.R.string.cancel), Ui.SECONDARY) { closePanel() },
            Ui.lp(this, w = 0, h = dp(48), weight = 1f, end = 8)
        )
        actions.addView(
            Ui.button(this, getString(R.string.settings_ok), Ui.PRIMARY) {
                intervalMs = ms
                maxClicks = limit
                Prefs.setClickIntervalMs(this, ms)
                Prefs.setMaxClicks(this, limit)
                updateMenuState()
                closePanel()
            },
            Ui.lp(this, w = 0, h = dp(48), weight = 1f)
        )
        card.addView(actions, Ui.lp(this, top = 18))

        refresh()
        showPanel(card, false)
    }

    // ════════════════════════════════════════════════════════════════════════
    // Layout editor
    // ════════════════════════════════════════════════════════════════════════

    private fun enterEditor() {
        if (editorMode) return
        stopClicking()
        closePanel()
        editorMode = true
        menuView?.visibility = View.GONE
        bubbleView?.visibility = View.GONE
        showEditorBar()
        rebuildControls()
    }

    private fun exitEditor(save: Boolean) {
        if (!editorMode) return
        if (save) {
            saveActiveProfile()
            toast(R.string.profile_saved)
        } else {
            val id = activeProfile?.id
            if (id != null) activeProfile = ProfileStore.find(this, id) ?: activeProfile
        }
        editorMode = false
        closePanel()
        removeEditorBar()
        menuView?.visibility = View.VISIBLE
        bubbleView?.visibility = View.VISIBLE
        rebuildControls()
    }

    private fun saveActiveProfile() {
        val profile = activeProfile ?: return
        ProfileStore.upsert(this, profile)
        Prefs.setActiveProfileId(this, profile.id)
    }

    private fun showEditorBar() {
        if (editorBar != null) return
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        fun add(v: View) {
            row.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(6) })
        }

        add(Ui.chip(this, getString(R.string.ed_add_button)) { addEditorControl(ControlWidget.BUTTON) })
        add(Ui.chip(this, getString(R.string.ed_add_move)) { addEditorControl(ControlWidget.MOVE_JOYSTICK) })
        add(Ui.chip(this, getString(R.string.ed_add_look)) { addEditorControl(ControlWidget.CAMERA_JOYSTICK) })
        val chip = Ui.chip(this, "▾ " + (activeProfile?.name ?: "")) { showProfilePicker() }
        profileChip = chip
        add(chip)
        add(Ui.chip(this, getString(R.string.ed_done), true) { exitEditor(true) })
        add(Ui.chip(this, getString(R.string.ed_discard)) { exitEditor(false) })

        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
            background = Ui.rounded(this@ClickerService, Ui.OVERLAY_BG, 24, Ui.STROKE, 1)
        }
        val params = overlayParams(WRAP, WRAP, 0, dp(10))
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (addOverlay(scroll, params)) editorBar = scroll
    }

    private fun removeEditorBar() {
        removeOverlay(editorBar)
        editorBar = null
        profileChip = null
    }

    private fun showProfilePicker() {
        val card = Ui.card(this).apply { isClickable = true }
        card.addView(Ui.text(this, getString(R.string.profiles_title), 18f, Ui.TEXT, true))
        ProfileStore.load(this).forEach { p ->
            val row = Ui.chip(this, p.name, p.id == activeProfile?.id, 14) {
                switchProfile(p.id)
                closePanel()
            }
            card.addView(row, Ui.lp(this, top = 8))
        }
        card.addView(
            Ui.button(this, getString(R.string.ed_new_profile), Ui.SECONDARY) {
                createProfile()
                closePanel()
            },
            Ui.lp(this, h = dp(46), top = 14)
        )
        showPanel(card, false)
    }

    private fun switchProfile(id: String) {
        saveActiveProfile()
        val next = ProfileStore.find(this, id) ?: return
        activeProfile = next
        Prefs.setActiveProfileId(this, id)
        profileChip?.text = "▾ " + next.name
        rebuildControls()
    }

    private fun createProfile() {
        saveActiveProfile()
        val count = ProfileStore.load(this).size + 1
        val p = ControlProfile(UUID.randomUUID().toString(), getString(R.string.default_profile_name, count), "")
        ProfileStore.upsert(this, p)
        activeProfile = p
        Prefs.setActiveProfileId(this, p.id)
        profileChip?.text = "▾ " + p.name
        rebuildControls()
    }

    private fun addEditorControl(widget: ControlWidget) {
        val profile = activeProfile ?: return
        val n = profile.controls.size
        val isButton = widget == ControlWidget.BUTTON
        val label = when (widget) {
            ControlWidget.BUTTON -> getString(R.string.widget_button)
            ControlWidget.MOVE_JOYSTICK -> getString(R.string.widget_move)
            ControlWidget.CAMERA_JOYSTICK -> getString(R.string.widget_look)
        }
        val offset = (n % 6) * 0.04f
        val width = if (isButton) 0.16f else 0.32f
        val event = ControlEvent(
            id = System.nanoTime(),
            label = label,
            type = ControlEventType.SCREEN,
            action = ControlAction.CLICK,
            widget = widget,
            x = 0.35f + offset,
            y = 0.30f + offset,
            width = width,
            height = width * 0.75f,
            sensitivity = if (widget == ControlWidget.CAMERA_JOYSTICK) 2f else 1f
        )
        profile.controls.add(event)
        rebuildControls()
    }

    private fun actionName(a: ControlAction): String = getString(
        when (a) {
            ControlAction.CLICK -> R.string.action_click
            ControlAction.HOLD -> R.string.action_hold
            ControlAction.TOGGLE -> R.string.action_toggle
            ControlAction.SPAM -> R.string.action_spam
            ControlAction.BACK -> R.string.action_back
            ControlAction.HOME -> R.string.action_home
            ControlAction.RECENTS -> R.string.action_recents
        }
    )

    private fun showControlPanel(cv: ControlView) {
        val ev = cv.event
        val isButton = ev.widget == ControlWidget.BUTTON
        var action = ev.action

        val card = Ui.card(this).apply { isClickable = true }
        card.addView(Ui.text(this, getString(R.string.control_properties), 18f, Ui.TEXT, true))

        val labelInput = Ui.input(this, getString(R.string.control_label), ev.label)
        val intervalInput = Ui.input(this, getString(R.string.control_interval), ev.intervalMs.toString(), true)

        val chipMap = mutableMapOf<ControlAction, TextView>()
        fun refreshChips() {
            chipMap.forEach { (a, tv) -> Ui.styleChip(tv, a == action) }
        }

        fun chipRow(actions: List<ControlAction>): LinearLayout {
            val row = LinearLayout(this)
            actions.forEach { a ->
                val c = Ui.chip(this, actionName(a), a == action, 4) {
                    action = a
                    refreshChips()
                }
                chipMap[a] = c
                row.addView(c, Ui.lp(this, w = 0, weight = 1f, end = 6))
            }
            return row
        }

        if (isButton) {
            card.addView(Ui.text(this, getString(R.string.control_label), 13f, Ui.MUTED), Ui.lp(this, top = 12, bottom = 6))
            card.addView(labelInput)
            card.addView(Ui.text(this, getString(R.string.control_action), 13f, Ui.MUTED), Ui.lp(this, top = 12, bottom = 6))
            card.addView(chipRow(listOf(ControlAction.CLICK, ControlAction.HOLD, ControlAction.TOGGLE, ControlAction.SPAM)))
            card.addView(Ui.text(this, getString(R.string.control_system), 13f, Ui.MUTED), Ui.lp(this, top = 12, bottom = 6))
            card.addView(chipRow(listOf(ControlAction.BACK, ControlAction.HOME, ControlAction.RECENTS)))
            card.addView(Ui.text(this, getString(R.string.control_interval), 13f, Ui.MUTED), Ui.lp(this, top = 12, bottom = 6))
            card.addView(intervalInput)
        }

        val sizeLabel = Ui.text(this, "", 13f, Ui.MUTED)
        val sizeSeek = SeekBar(this)
        Ui.styleSeekBar(sizeSeek)
        sizeSeek.max = 152
        sizeSeek.progress = (ev.width * 360f).roundToInt().coerceIn(48, 200) - 48
        fun refreshSize() {
            sizeLabel.text = getString(R.string.control_size_fmt, sizeSeek.progress + 48)
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) = refreshSize()
            override fun onStartTrackingTouch(bar: SeekBar) = Unit
            override fun onStopTrackingTouch(bar: SeekBar) = Unit
        })
        refreshSize()
        card.addView(sizeLabel, Ui.lp(this, top = 12, bottom = 4))
        card.addView(sizeSeek)

        val sensLabel = Ui.text(this, "", 13f, Ui.MUTED)
        val sensSeek = SeekBar(this)
        Ui.styleSeekBar(sensSeek)
        sensSeek.max = 55
        sensSeek.progress = ((ev.sensitivity - 0.5f) * 10f).roundToInt().coerceIn(0, 55)
        fun refreshSens() {
            sensLabel.text = getString(R.string.control_sensitivity_fmt, String.format(Locale.US, "%.1f", 0.5f + sensSeek.progress / 10f))
        }
        sensSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) = refreshSens()
            override fun onStartTrackingTouch(bar: SeekBar) = Unit
            override fun onStopTrackingTouch(bar: SeekBar) = Unit
        })
        refreshSens()
        if (!isButton) {
            card.addView(sensLabel, Ui.lp(this, top = 12, bottom = 4))
            card.addView(sensSeek)
        }

        card.addView(
            Ui.text(this, getString(R.string.control_target_hint), 12f, Ui.MUTED),
            Ui.lp(this, top = 14)
        )

        val actions = LinearLayout(this)
        actions.addView(
            Ui.button(this, getString(android.R.string.cancel), Ui.SECONDARY) { closePanel() },
            Ui.lp(this, w = 0, h = dp(48), weight = 1f, end = 8)
        )
        actions.addView(
            Ui.button(this, getString(R.string.settings_ok), Ui.PRIMARY) {
                if (isButton) {
                    ev.label = labelInput.text.toString().trim().ifBlank { ev.label }
                    ev.action = action
                    ev.intervalMs = intervalInput.text.toString().toLongOrNull()?.coerceIn(40L, 10000L) ?: ev.intervalMs
                } else {
                    ev.sensitivity = 0.5f + sensSeek.progress / 10f
                }
                ev.width = (sizeSeek.progress + 48) / 360f
                ev.height = ev.width * 0.75f
                closePanel()
                rebuildControls()
            },
            Ui.lp(this, w = 0, h = dp(48), weight = 1f)
        )
        card.addView(actions, Ui.lp(this, top = 16))
        card.addView(
            Ui.button(this, getString(R.string.control_delete), Ui.DANGER_KIND) {
                activeProfile?.controls?.remove(ev)
                closePanel()
                rebuildControls()
            },
            Ui.lp(this, h = dp(44), top = 8)
        )

        showPanel(card, true)
    }

    // ════════════════════════════════════════════════════════════════════════
    // Profile controls (buttons + joysticks)
    // ════════════════════════════════════════════════════════════════════════

    private inner class ControlView(
        val event: ControlEvent,
        val view: View,
        val params: WindowManager.LayoutParams
    ) {
        var knob: View? = null
        var marker: View? = null
        var markerParams: WindowManager.LayoutParams? = null
        var active = false
        val session = StrokeSession()

        val repeat = object : Runnable {
            override fun run() {
                if (!active) return
                val t = targetPx(event)
                if (t != null) tapAt(t[0], t[1])
                handler.postDelayed(this, event.intervalMs.coerceIn(40L, 10000L))
            }
        }

        fun stopAll() {
            active = false
            handler.removeCallbacks(repeat)
            session.cancel()
        }
    }

    /** Screen position the control acts on, or null when no target was set yet. */
    private fun targetPx(ev: ControlEvent): FloatArray? {
        if (ev.targetX < 0f || ev.targetY < 0f) {
            toast(R.string.toast_no_target)
            return null
        }
        val s = screenSize()
        return floatArrayOf(ev.targetX * s.x, ev.targetY * s.y)
    }

    private fun clearControls() {
        controlViews.forEach { cv ->
            cv.stopAll()
            removeOverlay(cv.view)
            removeOverlay(cv.marker)
        }
        controlViews.clear()
    }

    private fun rebuildControls() {
        clearControls()
        if (!overlaysEnabled) return
        val profile = activeProfile ?: return
        if (!profile.screenEventsEnabled && !editorMode) return
        val screen = screenSize()
        var index = 0
        profile.controls.forEach { ev ->
            if (ev.type != ControlEventType.SCREEN) return@forEach
            if (!ev.enabled && !editorMode) return@forEach
            index++
            addControlView(ev, index, screen)
        }
    }

    private fun controlBackground(active: Boolean) =
        Ui.rounded(
            this,
            if (active) 0xEE059669.toInt() else 0xCC7C3AED.toInt(),
            16,
            if (editorMode) Color.WHITE else 0x66FFFFFF,
            1
        )

    private fun addControlView(ev: ControlEvent, index: Int, screen: Point) {
        val isButton = ev.widget == ControlWidget.BUTTON
        val sizeDp = (ev.width * 360f).coerceIn(48f, 200f)
        val wPx = dp(sizeDp.roundToInt())
        val hPx = if (isButton) dp((sizeDp * 0.75f).coerceAtLeast(44f).roundToInt()) else wPx

        var knob: View? = null
        val view: View = if (isButton) {
            Ui.text(this, if (editorMode) "$index · ${ev.label}" else ev.label, 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(dp(4), dp(2), dp(4), dp(2))
                background = controlBackground(false)
            }
        } else {
            val frame = FrameLayout(this)
            frame.background = Ui.oval(0x66141420, Ui.ACCENT, dp(2))
            val k = View(this)
            k.background = Ui.oval(0xDDFFFFFF.toInt())
            frame.addView(k, FrameLayout.LayoutParams(wPx / 3, wPx / 3, Gravity.CENTER))
            val tag = (if (editorMode) "$index " else "") +
                (if (ev.widget == ControlWidget.MOVE_JOYSTICK) getString(R.string.widget_move) else getString(R.string.widget_look))
            frame.addView(
                Ui.text(this, tag, 9f, Ui.MUTED, true),
                FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(6) }
            )
            knob = k
            frame
        }

        val params = overlayParams(wPx, hPx)
        params.x = (ev.x * screen.x).roundToInt().coerceIn(0, (screen.x - wPx).coerceAtLeast(0))
        params.y = (ev.y * screen.y).roundToInt().coerceIn(0, (screen.y - hPx).coerceAtLeast(0))

        val cv = ControlView(ev, view, params)
        cv.knob = knob
        if (!addOverlay(view, params)) return
        controlViews.add(cv)

        if (editorMode) {
            addMarker(cv, index, screen, wPx)
            attachEditTouch(cv)
        } else {
            attachRunTouch(cv)
        }
    }

    private fun addMarker(cv: ControlView, index: Int, screen: Point, controlWidthPx: Int) {
        val ev = cv.event
        val size = dp(36)
        val marker = Ui.text(this, index.toString(), 13f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER
            background = Ui.oval(Ui.OK, Color.WHITE, dp(2))
        }
        // Legacy controls without a target get a default one next to the control.
        if (ev.targetX < 0f || ev.targetY < 0f) {
            val cx = cv.params.x + controlWidthPx / 2f + dp(80)
            val cy = cv.params.y + controlWidthPx / 2f
            ev.targetX = (cx / screen.x).coerceIn(0.02f, 0.98f)
            ev.targetY = (cy / screen.y).coerceIn(0.02f, 0.98f)
        }
        val mp = overlayParams(size, size)
        mp.x = (ev.targetX * screen.x - size / 2f).roundToInt().coerceIn(0, (screen.x - size).coerceAtLeast(0))
        mp.y = (ev.targetY * screen.y - size / 2f).roundToInt().coerceIn(0, (screen.y - size).coerceAtLeast(0))
        if (!addOverlay(marker, mp)) return
        cv.marker = marker
        cv.markerParams = mp

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        marker.setOnTouchListener { _, m ->
            when (m.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = m.rawX
                    downY = m.rawY
                    startX = mp.x
                    startY = mp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    mp.x = (startX + m.rawX - downX).roundToInt()
                    mp.y = (startY + m.rawY - downY).roundToInt()
                    clampParams(marker, mp)
                    updateOverlay(marker, mp)
                }
                MotionEvent.ACTION_UP -> {
                    val s = screenSize()
                    ev.targetX = (mp.x + size / 2f) / s.x
                    ev.targetY = (mp.y + size / 2f) / s.y
                }
            }
            true
        }
    }

    /** Editor mode: drag the control, tap it to open its properties. */
    private fun attachEditTouch(cv: ControlView) {
        val p = cv.params
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        cv.view.setOnTouchListener { _, m ->
            when (m.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = m.rawX
                    downY = m.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = m.rawX - downX
                    val dy = m.rawY - downY
                    if (!moved && (abs(dx) > touchSlop || abs(dy) > touchSlop)) moved = true
                    if (moved) {
                        p.x = (startX + dx).roundToInt()
                        p.y = (startY + dy).roundToInt()
                        clampParams(cv.view, p)
                        updateOverlay(cv.view, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val s = screenSize()
                    cv.event.x = p.x / s.x.toFloat()
                    cv.event.y = p.y / s.y.toFloat()
                    if (!moved) showControlPanel(cv)
                }
            }
            true
        }
    }

    /** Normal mode: the control triggers its action on the target point. */
    private fun attachRunTouch(cv: ControlView) {
        val ev = cv.event
        cv.view.setOnTouchListener { v, m ->
            when (m.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.7f
                    onControlDown(cv, m)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (ev.widget != ControlWidget.BUTTON) joystickMove(cv, m)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    onControlUp(cv)
                }
            }
            true
        }
    }

    private fun onControlDown(cv: ControlView, m: MotionEvent) {
        val ev = cv.event
        if (ev.widget != ControlWidget.BUTTON) {
            val t = targetPx(ev) ?: return
            cv.session.start(t[0], t[1])
            joystickMove(cv, m)
            return
        }
        when (ev.action) {
            ControlAction.CLICK -> {
                val t = targetPx(ev)
                if (t != null) tapAt(t[0], t[1])
            }
            ControlAction.SPAM -> {
                if (targetPx(ev) != null) {
                    cv.active = true
                    handler.removeCallbacks(cv.repeat)
                    handler.post(cv.repeat)
                }
            }
            ControlAction.TOGGLE -> {
                if (cv.active) {
                    cv.active = false
                    handler.removeCallbacks(cv.repeat)
                } else if (targetPx(ev) != null) {
                    cv.active = true
                    handler.removeCallbacks(cv.repeat)
                    handler.post(cv.repeat)
                }
                cv.view.background = controlBackground(cv.active)
            }
            ControlAction.HOLD -> {
                val t = targetPx(ev)
                if (t != null) cv.session.start(t[0], t[1])
            }
            ControlAction.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ControlAction.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            ControlAction.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }

    private fun onControlUp(cv: ControlView) {
        val ev = cv.event
        if (ev.widget != ControlWidget.BUTTON) {
            cv.session.end()
            cv.knob?.let {
                it.translationX = 0f
                it.translationY = 0f
            }
            return
        }
        when (ev.action) {
            ControlAction.SPAM -> {
                cv.active = false
                handler.removeCallbacks(cv.repeat)
            }
            ControlAction.HOLD -> cv.session.end()
            else -> Unit
        }
    }

    private fun joystickMove(cv: ControlView, m: MotionEvent) {
        if (!cv.session.active) return
        val c = centerOf(cv.view)
        val radius = min(cv.view.width, cv.view.height) / 2f
        var dx = m.rawX - c[0]
        var dy = m.rawY - c[1]
        val dist = hypot(dx, dy)
        if (radius > 0f && dist > radius) {
            dx = dx / dist * radius
            dy = dy / dist * radius
        }
        cv.knob?.let {
            it.translationX = dx
            it.translationY = dy
        }
        val t = targetPx(cv.event) ?: return
        val s = screenSize()
        val k = cv.event.sensitivity
        cv.session.moveTo(
            (t[0] + dx * k).coerceIn(0f, s.x.toFloat()),
            (t[1] + dy * k).coerceIn(0f, s.y.toFloat())
        )
    }

    // ════════════════════════════════════════════════════════════════════════
    // Rotation
    // ════════════════════════════════════════════════════════════════════════

    private fun rebuildAfterRotation() {
        if (!overlaysEnabled || instance == null) return
        closePanel()
        if (menuView != null) {
            removeMenu()
            showMenu()
        }
        bubbleView?.let { v -> bubbleParams?.let { clampToScreen(v, it) } }
        clickPoints.forEach { clampToScreen(it.view, it.params) }
        if (editorMode) {
            removeEditorBar()
            showEditorBar()
        }
        rebuildControls()
    }
}
