package com.nostick.clicker

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import java.util.UUID

class ControlDashboardActivity : AppCompatActivity() {
    private val purple = Color.rgb(187, 134, 252)
    private val profiles = mutableListOf<ControlProfile>()
    private var selected = 0
    private lateinit var profileSpinner: Spinner
    private lateinit var packageInput: EditText
    private lateinit var spamInput: EditText
    private lateinit var screenCheck: CheckBox
    private lateinit var keyCheck: CheckBox
    private lateinit var status: TextView

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        profiles.addAll(ProfileStore.load(this))
        if (profiles.isEmpty()) profiles.add(ControlProfile(UUID.randomUUID().toString(), "Default", ""))
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(Color.rgb(18, 18, 18)) }
        root.addView(TextView(this).apply { text = getString(R.string.dashboard_title); textSize = 26f; setTextColor(Color.WHITE); setPadding(0, 0, 0, 8) })
        status = TextView(this).apply { text = if (ClickerService.instance != null) getString(R.string.service_running) else getString(R.string.service_not_running); setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 16) }
        root.addView(status)
        profileSpinner = Spinner(this)
        profileSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, profiles.map { it.name })
        profileSpinner.setSelection(selected)
        profileSpinner.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { selected = position; loadSelected() }
        })
        root.addView(label(R.string.selected_profile)); root.addView(profileSpinner)
        packageInput = input(R.string.profile_package); root.addView(packageInput)
        screenCheck = CheckBox(this).apply { text = getString(R.string.enable_screen_events); setTextColor(Color.WHITE) }; root.addView(screenCheck)
        keyCheck = CheckBox(this).apply { text = getString(R.string.enable_key_events); setTextColor(Color.WHITE) }; root.addView(keyCheck)
        root.addView(label(R.string.spam_speed_ms))
        spamInput = input(R.string.spam_speed_hint).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("120") }; root.addView(spamInput)
        root.addView(label(R.string.dashboard_help))
        root.addView(button(R.string.save_profile) { saveSelected() })
        root.addView(button(R.string.start_controls) { ClickerService.instance?.revealControls(); status.text = getString(R.string.service_running) })
        root.addView(button(R.string.stop_controls) { ClickerService.instance?.stopAllControls(); status.text = getString(R.string.service_stopped) })
        root.addView(button(R.string.open_control_editor) { ClickerService.instance?.openEditorFromDashboard(); finish() })
        root.addView(button(R.string.close_dashboard) { finish() })
        setContentView(root); loadSelected()
    }

    private fun loadSelected() {
        if (!::packageInput.isInitialized) return
        val p = profiles[selected]
        packageInput.setText(p.packageName); screenCheck.isChecked = p.screenEventsEnabled; keyCheck.isChecked = p.keyEventsEnabled
        val spam = p.controls.firstOrNull { it.action == ControlAction.SPAM }?.intervalMs ?: 120L
        spamInput.setText(spam.toString())
    }

    private fun saveSelected() {
        val p = profiles[selected]
        val name = EditText(this).apply { setText(p.name); hint = getString(R.string.profile_name); setTextColor(Color.WHITE) }
        AlertDialog.Builder(this, R.style.Theme_NostickClicker_Dialog).setTitle(R.string.save_profile).setView(name)
            .setPositiveButton(R.string.confirm_save) { _, _ ->
                p.name = name.text.toString().ifBlank { "Profile" }
                p.packageName = packageInput.text.toString().trim(); p.screenEventsEnabled = screenCheck.isChecked; p.keyEventsEnabled = keyCheck.isChecked
                val ms = spamInput.text.toString().toLongOrNull()?.coerceIn(10L, 10000L) ?: 120L
                p.controls.filter { it.action == ControlAction.SPAM }.forEach { it.intervalMs = ms }
                ProfileStore.upsert(this, p); ClickerService.instance?.activateProfile(p)
                Toast.makeText(this, R.string.profile_saved, Toast.LENGTH_SHORT).show()
            }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun label(id: Int) = TextView(this).apply { text = getString(id); setTextColor(Color.LTGRAY); setPadding(0, 10, 0, 4) }
    private fun input(hint: Int) = EditText(this).apply { this.hint = getString(hint); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine(true) }
    private fun button(id: Int, action: () -> Unit) = Button(this).apply { text = getString(id); setTextColor(Color.BLACK); setBackgroundColor(purple); setOnClickListener { action() } }
}
